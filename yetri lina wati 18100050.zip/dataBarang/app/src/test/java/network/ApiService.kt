package com.informatika.databarang.network
import com.informatika.databarang.model.ResponseActionBarang
import com.informatika.databarang.model.ResponseBarang
import ...
        interface ApiService {
            @GET( value: "read.php")
            fun getBarang(): call<ResponseBarang>

            @FormUrlEncoded
            @POST(value: "create.php")
            fun insertBarang(
                @field( value: :"Nama_barang") namaBarang: String?,
                 @field( value: :"Jumlah_barang") jmlBarang: String?
            ): Call<ResponseActionBarang>

            @FormUrlEncoded
            @POST(value: "update.php")
            fun updateBarang(
                @field( value: :"id") id: String?,

            ): Call<ResponseActionBarang>

            @FormUrlEncoded
            @POST(value: "delete.php")
            fun deleteBarang(
                @field( value: :"id") namaBarang: String?,
            ): Call<ResponseActionBarang>
            }


}